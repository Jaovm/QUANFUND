# -*- coding: utf-8 -*-
"""
Pacote para componentes da interface do usuário (Streamlit).

Este pacote conterá módulos que definem as diferentes seções e componentes
visuais do aplicativo Streamlit, como painéis de entrada, gráficos, tabelas, etc.
"""

__version__ = "0.0.1"
__author__ = "Manus AI Agent"
__email__ = ""

