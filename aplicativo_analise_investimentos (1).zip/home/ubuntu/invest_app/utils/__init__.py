# -*- coding: utf-8 -*-
"""
Pacote de utilitários.

Este pacote contém módulos com funções auxiliares, classes base,
constantes e outras ferramentas que são usadas em várias partes do aplicativo.
"""

__version__ = "0.0.1"
__author__ = "Manus AI Agent"
__email__ = ""

